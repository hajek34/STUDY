/*
 ************** SHOPPING LIST APP ****************

  ***Created by: kladivko; hajek34; stanek29***

     ********____May___2023___**********
**************************************************
*/

package com.example.shopping_list;

import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import java.util.ArrayList;
import android.content.Context;
import android.gesture.Gesture;
import android.media.Image;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    // Pole - položky seznamu //
    static ArrayList<String> items;
    // Seznam //
    static ListView listView;
    // Vložení * button //
        EditText input;
    //ImageView enter
    ImageView enter;
    static Context context;
    static ListViewAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list);
        input = findViewById(R.id.input);
        enter = findViewById(R.id.add);
        context =getApplicationContext();



        items = new ArrayList<>();
        items.add("Jablko");
        items.add("Banán");
        items.add("Hruška");
        items.add("Jahody");
        items.add("Borůvky");
        items.add("Mléko");
        items.add("Šunka");
        items.add("Sýr");
        items.add("Máslo");
        items.add("Mrkev");
        items.add("Maso");
        items.add("Pivo(0,5l)");
        items.add("Džus");
        items.add("Párek");
        items.add("Džem");
        items.add("Jogurt");
        items.add("Čokoláda");
        items.add("Losos");
        items.add("Brambory");
        items.add("Hrášek");
        items.add("Chléb");
        items.add("Rohlík");

        listView.setLongClickable(true);
        adapter = new ListViewAdapter(this, items);
        listView.setAdapter(adapter);

        // odebrání položky při dlouhém držení na položce.. //
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l){
                removeItem(i);
                return false;
            }
        });

        // Přidání položky do seznamu po stisknutí tlačítka přidat //
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                String text = input.getText().toString();
                if (text == null || text.length() == 0) {
                    makeToast("Zadejte položku...");
                } else {
                    addItem(text);
                    input.setText("");
                    makeToast("Přidáno: " + text);
                }
            }
        });
        loadContent();
    }

        // Funkce přidání do seznamu ze souboru do ListView//

        public void loadContent() {
        File path = getApplicationContext().getFilesDir();
        File readFrom = new File(path, "list.txt");
        byte [] content = new byte[(int)readFrom.length()];

        FileInputStream stream = null;
        try {
            stream = new FileInputStream(readFrom);
            stream.read(content);

            String s = new String(content);
            // [Jablko, Banán, Hruška, Jahody]
            s = s.substring(1, s.length() - 1);
            String split[] = s.split(", ");

            // V Seznamu potravin nemusí být žádné položky://
            if (split.length == 1 && split[0].isEmpty())
                items = new ArrayList<>();
            else items = new ArrayList<>(Arrays.asList(split));

            adapter = new ListViewAdapter(this, items);
            listView.setAdapter(adapter);
        }   catch (Exception e) {
            e.printStackTrace();
        }

        }
        @Override
        protected void onDestroy() {
        File path = getApplicationContext().getFilesDir();
        try {
            FileOutputStream writer = new FileOutputStream(new File(path, "list.txt"));
            writer.write(items.toString().getBytes());
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onDestroy();

        }

        // Funkce odstranění položky dle indexu//

        public static void removeItem(int i) {
            makeToast("Odstraněno: " + items.get(i));
            items.remove(i);
            listView.setAdapter(adapter);
        }

        // Funkce přidání položky //
        public static void addItem(String item) {
        items.add(item);
        listView.setAdapter(adapter);
        }

        // Hláška o provedené změně v seznamu //
        static Toast t;

        private static void makeToast(String s) {
            if (t !=null) t.cancel();
            t = Toast.makeText(context, s, Toast.LENGTH_SHORT);
            t.show();
        }



}
