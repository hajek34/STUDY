package com.example.bmi.core;

/* Výpočet BMI */


public class Health {

    private String errorMessage;
    public String getErrorMessage() {
        return errorMessage;
    }

    public double calculateBMI(double heightCm, double weightKg) {
        double bmiIndex = -1;
        if ((heightCm <= 0 && weightKg <= 0)) {
            errorMessage = "Výška a váha nemohou být 0 a nižší!";

        } else {
            bmiIndex = weightKg / ((heightCm/100) * (heightCm / 100));
        }
        return bmiIndex;
    }

    public String determineCategory (double bmiIndex) {
        String bmiCategory = "";

        if(bmiIndex < 16) {
            bmiCategory = "Těžká podváha!";
        } else if (bmiIndex >= 16 && bmiIndex < 17) {
            bmiCategory ="V normě, ideál";
        } else if (bmiIndex >= 17 && bmiIndex < 18.5) {
            bmiCategory = "Je to ok, pár Kg navíc..!";
        } else if (bmiIndex >= 18.5 && bmiIndex < 25) {
            bmiCategory ="Jsi akorát!";
        } else if (bmiIndex >= 25 && bmiIndex < 30) {
            bmiCategory ="Střední obezita";
        } else if (bmiIndex >= 30 && bmiIndex < 35) {
            bmiCategory ="Těžká obezita!!!";
        } else if (bmiIndex >= 35 && bmiIndex < 40) {
            bmiCategory ="Těžká obezita 2.stupně!!!";
        } else if (bmiIndex >= 40) {
            bmiCategory ="Těžká obezita 3.stupně! Vyhledejte lékaře!";
        }
        return bmiCategory;
    }
}
